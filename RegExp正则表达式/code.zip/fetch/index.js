const Koa = require("koa");
const Router = require("koa-router");
const koaBody = require("koa-body");
const static = require("koa-static");
let app = new Koa();
let router = new Router();
app.use(koaBody());
app.use(static(__dirname+"/static"));
// 必须参数
router.get("/test/:id",ctx=>{
   let res =   ctx.params.id
//    ctx.request.query  querystring :查询参数；name=zhangsan&age=20
   console.log(res);
    ctx.body = "some value....";
})
router.get("/get",ctx=>{
    console.log("get请求过来");
    ctx.body = {
        info:"get返还数据"
    }
})
router.post("/post",ctx=>{
    console.log(ctx.request.body);
    ctx.body = {
        info:"post返还数据"
    };
})

router.get("/axios",ctx=>{
    console.log("axios get请求过来");
    ctx.body = {
        info:"get返还数据"
    }
})
router.post("/axiosPost",ctx=>{
    console.log("axios post请求过来",ctx.request.body);
    ctx.body = {
        info:"post返还数据"
    }
})
router.get("/myaxios",ctx=>{
    ctx.body = {
        info:"myaxios get返还数据"
    }
})

app.use(router.routes());
app.listen(4000);
