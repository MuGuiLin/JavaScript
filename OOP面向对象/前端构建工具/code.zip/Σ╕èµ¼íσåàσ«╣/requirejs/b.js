console.log("b.js");
define({
    name:"b.js"
});