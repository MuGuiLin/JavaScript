console.log("a文件");

let a = 10;
let obj = {
    name:"张三",
    age:20,
    fn:function(){
        console.log("fn...")
    }
}

let fn = function(){
    console.log(1111);
}
//方式一 export default： 默认导出 ：只能导出一个； 按需导出；
// export default fn;
// export {fn as default}
// 导出方式二：可以导出多个；
// 写法一：
// export let num = 10;
// 写法二：
let num = 10;
let str = "我是字符串";
export { num }
// 别名 as
// export { str };
export {str as mystr}

export {a}


// 模块化方式：1、es6模块化；2.commonjs规范；（nodejs）
